if (typeof base2 == "undefined")
 document.write('<script type="text/javascript" src="my.js"><\/script>');
